﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter two numbers");
            Console.ReadLine();
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            bool flag = true;
            

            CalculateValues cv = new CalculateValues();
            while (flag)
            {
                Console.WriteLine("Enter 1 for Addition\n Enter 2 for Substracrion\n Enter 3 for Multiplication\n Enter 4 for Division");
                int choice = int.Parse(Console.ReadLine());

                int result = 0;
                switch (choice)
                {
                    case 1:
                        Console.WriteLine(cv.Addition(num1, num2));
                        break;

                    case 2:
                        Console.WriteLine(cv.Subtraction(num2, num1));
                        break;
                    case 3:
                        Console.WriteLine(cv.Multiplication(num1, num2));
                        break;
                    case 4:
                        Console.WriteLine(cv.Division(num1, num2));
                        break;
                    default:
                        Console.WriteLine("Invalid Choice!");
                        break;
                }
                Console.WriteLine("The result is: " + result);
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }
        }
    }
}
